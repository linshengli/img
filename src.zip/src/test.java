import jdbm.PrimaryTreeMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import org.apache.derby.iapi.util.ByteArray;

import java.io.*;
import java.util.Properties;

public class test {
    public static void testRec(){
        /** create (or open existing) database */
        String fileName = "hash.index";
        RecordManager recMan = null;
        try {
            recMan = RecordManagerFactory.createRecordManager(fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }

        /** Creates TreeMap which stores data in database.
         *  Constructor method takes recordName (something like SQL table name)*/
        String recordName = "firstTreeMap";
        PrimaryTreeMap<Integer,String> treeMap = recMan.treeMap(recordName);

        /** add some stuff to map*/
        treeMap.put(1, "One");
        treeMap.put(2, "Two");
        treeMap.put(3, "Three");

        System.out.println(treeMap.keySet());
        // > [1, 2, 3]

        /** Map changes are not persisted yet, commit them (save to disk) */
        try {
            recMan.commit();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(treeMap.keySet());
        // > [1, 2, 3]

        /** Delete one record. Changes are not commited yet, but are visible. */
        treeMap.remove(2);

        System.out.println(treeMap.keySet());
        // > [1, 3]

        /** Did not like change. Roolback to last commit (undo record remove). */
        try {
            recMan.rollback();
        } catch (IOException e) {
            e.printStackTrace();
        }

        /** Key 2 was recovered */
        System.out.println(treeMap.keySet());
        // > [1, 2, 3]

        /** close record manager */
        try {
            recMan.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static byte[] hash(String str){
        int hashCode = str.hashCode();
        return new byte[] {
                (byte) ((hashCode >> 24) & 0xFF),
                (byte) ((hashCode >> 16) & 0xFF),
                (byte) ((hashCode >> 8) & 0xFF),
                (byte) (hashCode & 0xFF)
        };
    }

    public static int byteArrayToInt(byte[] b) {
        return   b[3] & 0xFF |
                (b[2] & 0xFF) << 8 |
                (b[1] & 0xFF) << 16 |
                (b[0] & 0xFF) << 24;
    }


    public static String hashStr(String str) {
        int hashCode = str.hashCode();
        return String.valueOf(hashCode);
    }

    public static void main(String[] args) {
        System.out.println(hashStr("111382"));
//        testRec();

    }

}
