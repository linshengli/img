import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

public class dbquery {
    static int pageSize;
    static int hashIndex;

    public static String hashStr(String str) {
        int hashCode = str.hashCode();
        return String.valueOf(hashCode);
    }

    public static void outputQueryStr(List<Integer> list) {
        ArrayList<String> outStrings = new ArrayList<String>();
        RandomAccessFile in = null;
        int censusYearSize = 5;
        int blockIdSize = 5;
        int basePropIdsize = 10;
        int nameSize = 100;
        ;
        int addressStringSize = 100;
        int clueSmallAreaSize = 100;
        int constructionYearSize = 5;
        int refurnishYearStringSize = 100;
        int numFloorSize = 2;
        int propIdSize = 10;
        int accRateSize = 5;
        ;
        int prespaceSize = 100;
        int accessTypeSize = 50;
        int accessDespSize = 100;
        int bicycle_spaceSize = 5;
        int hasShowerSize = 2;
        int xcoordinateSize = 10;
        int ycoordinateSize = 10;
        int locationSize = 30;
        try {
            in = new RandomAccessFile("heap." + pageSize, "r");
            int index = 0;
            while (index < list.size()) {
                //declare current offset
                int currOffset = list.get(index);
                index++;
                //move to offset
                in.seek(currOffset);
                //get the name
                byte[] readByte = new byte[nameSize];
                in.read(readByte);
                //if name matches query
                //declare strings to be printed
                String censusYear;
                String blockId;
                String propId;
                String basePropId;
                String name;
                String addressString;
                String clueSmallArea;
                String constructionYear;
                String refurnishYearString;
                String numFloor;
                String accRate;
                String prespace;
                String accessType;
                String accessDesp;
                String bicycle_space;
                String hasShower;
                String xcoordinate;
                String ycoordinate;
                String location;
                in.seek(currOffset);
                byte[] temp1 = new byte[censusYearSize];
                in.read(temp1);
                censusYear = new String(temp1);

                in.seek(currOffset + censusYearSize);
                byte[] temp2 = new byte[blockIdSize];
                in.read(temp2);
                blockId = new String(temp2);


                in.seek(currOffset + censusYearSize + blockIdSize);
                byte[] temp10 = new byte[propIdSize];
                in.read(temp10);
                propId = new String(temp10);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize);
                byte[] temp3 = new byte[basePropIdsize];
                in.read(temp3);
                basePropId = new String(temp3);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize);
                byte[] nameByte = new byte[nameSize];
                in.read(nameByte);


                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize + nameSize);
                byte[] temp5 = new byte[addressStringSize];
                in.read(temp5);
                addressString = new String(temp5);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize + nameSize + addressStringSize);
                byte[] temp6 = new byte[clueSmallAreaSize];
                in.read(temp6);
                clueSmallArea = new String(temp6);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize);
                byte[] temp7 = new byte[constructionYearSize];
                in.read(temp7);
                constructionYear = new String(temp7);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize);
                byte[] temp8 = new byte[refurnishYearStringSize];
                in.read(temp8);
                refurnishYearString = new String(temp8);

                in.seek(currOffset + censusYearSize + blockIdSize + propIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize);
                byte[] temp9 = new byte[numFloorSize];
                in.read(temp9);
                numFloor = new String(temp9);


                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize);
                byte[] temp11 = new byte[accRateSize];
                in.read(temp11);
                accRate = new String(temp11);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize);
                byte[] temp12 = new byte[prespaceSize];
                in.read(temp12);
                prespace = new String(temp12);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize);
                byte[] temp13 = new byte[accessTypeSize];
                in.read(temp13);
                accessType = new String(temp13);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize);
                byte[] temp14 = new byte[accessDespSize];
                in.read(temp14);
                accessDesp = new String(temp14);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize);
                byte[] temp15 = new byte[bicycle_spaceSize];
                in.read(temp15);
                bicycle_space = new String(temp15);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize + bicycle_spaceSize);
                byte[] temp16 = new byte[hasShowerSize];
                in.read(temp16);
                hasShower = new String(temp16);

                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize + bicycle_spaceSize + hasShowerSize);
                byte[] temp17 = new byte[xcoordinateSize];
                in.read(temp17);
                xcoordinate = new String(temp17);


                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize + bicycle_spaceSize + hasShowerSize
                        + xcoordinateSize);
                byte[] temp18 = new byte[ycoordinateSize];
                in.read(temp18);
                ycoordinate = new String(temp18);


                in.seek(currOffset + censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize + bicycle_spaceSize + hasShowerSize
                        + xcoordinateSize + ycoordinateSize);
                byte[] temp19 = new byte[locationSize];
                in.read(temp19);
                location = new String(temp19);


                String outString =
                        "censusYear: " + censusYear +
                                "\n blockId: " + blockId +
                                "\n Property ID: " + propId +
                                "\n Base property ID: " + basePropId +
                                "\n Building name: " + new String(nameByte) +
                                "\n addressString: " + addressString +
                                "\n clueSmallArea: " + clueSmallArea +
                                "\n constructionYear: " + constructionYear +
                                "\n refurnishYear: " + refurnishYearString +
                                "\n numFloor: " + numFloor +
                                "\n propId: " + propId +
                                "\n accRate: " + accRate +
                                "\n prespace: " + prespace +
                                "\n accessType: " + accessType +
                                "\n accessDesp: " + accessDesp +
                                "\n bicycle_space: " + bicycle_space +
                                "\n hasShower: " + hasShower +
                                "\n xcoordinate: " + xcoordinate +
                                "\n ycoordinate: " + ycoordinate +
                                "\n location: " + location +
                                "\n";
                outStrings.add(outString);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(outStrings);
    }

    public static void main(String[] args) {
//        dbquery  3 649 10000
        String strPage = args[args.length - 1];
        pageSize = Integer.valueOf(strPage);

        hashIndex = Integer.valueOf(args[args.length - 3]);
        String hashValue = hashStr(args[args.length - 2]);

        Properties properties = new Properties();

        try {
            properties.load(new FileReader("heap." + pageSize + ".index"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Integer> list = new LinkedList<>();
        if (properties.getProperty(hashValue) != null) {
            String pos = properties.getProperty(hashValue);
            int posi = Integer.parseInt(pos);
            list.add(posi);
            int i = 1;
            while (properties.getProperty(hashValue + "_" + i) != null) {
                pos = properties.getProperty(hashValue + "_" + i);
                posi = Integer.parseInt(pos);
                list.add(posi);
                i++;
            }
        }
        outputQueryStr(list);
    }
}
