import com.opencsv.CSVReader;

import java.io.*;
import java.util.Arrays;
import java.util.Properties;

public class dbload {
    // declare terminal arguments
    static int pageSize;
    static String dataFile;
    static int hashIndex;


    public static String hashStr(String str) {
        int hashCode = str.hashCode();
        return String.valueOf(hashCode);
    }

    public static void main(String[] args) throws FileNotFoundException {
        // read terminal arguments
        try {
            pageSize = Integer.parseInt(args[args.length - 3]);
            hashIndex = Integer.parseInt(args[args.length - 1]);
        } catch (Exception e) {
            System.out.println("Error,wrong format.");
            System.exit(0);
        }
        File file = new File(args[2]);
        if (!args[0].equals("-p")) {
            System.out.print("Wrong file format, please input the args again");
            System.exit(0);
        }
        if (args[1].isEmpty()) {
            System.out.print("Wrong file format, please input the args again");
            System.exit(0);
        }

        if (args[2].isEmpty()) {
            System.out.print("Wrong file format, please input the args again");
            System.exit(0);
        }

        if (!file.exists()) {
            System.out.print("Wrong file format, please input the args again");
            System.exit(0);
        }
        CSVReader reader = new CSVReader(new FileReader(file), '\t');

        DataOutputStream outputStream = null;
        DataOutputStream indexStream = null;
        // declare database variables
        String censusYear;
        String blockId;
        String basePropId;
        String name;
        String addressString;
        String clueSmallArea;
        String constructionYear;
        String refurnishYearString;
        String numFloor;
        String propId;
        String accRate;
        String prespace;
        String accessType;
        String accessDesp;
        String bicycle_space;
        String hasShower;
        String xcoordinate;
        String ycoordinate;
        String location;

        int censusYearSize = 5;
        int blockIdSize = 5;
        int basePropIdsize = 10;
        int nameSize = 100;
        ;//120
        int addressStringSize = 100;
        int clueSmallAreaSize = 100;
        int constructionYearSize = 5;
        int refurnishYearStringSize = 100;
        int numFloorSize = 2;
        int propIdSize = 10;
        int accRateSize = 5;
        ;//322
        int prespaceSize = 100;
        int accessTypeSize = 50;
        int accessDespSize = 100;
        int bicycle_spaceSize = 5;
        int hasShowerSize = 2;
        int xcoordinateSize = 10;
        int ycoordinateSize = 10;
        int locationSize = 30;
        //307
        //120 + 322 + 307 = 749
        int recordSize = censusYearSize + blockIdSize + basePropIdsize + nameSize + addressStringSize + clueSmallAreaSize + constructionYearSize + refurnishYearStringSize + numFloorSize + propIdSize + accRateSize + prespaceSize + accessTypeSize + accessDespSize + bicycle_spaceSize + hasShowerSize
                + xcoordinateSize + ycoordinateSize + locationSize;

        // error checking: pageSize must be larger than record size
        if (pageSize < recordSize) {
            System.out.println("Page size must be larger or equal to " + recordSize + "\nDbload will not run.");
            System.exit(0);
        }
        int recordPerPage = pageSize / recordSize;
        int remainderPage = pageSize % recordSize;

        // counters to keep track of how many pages and records there are
        int recordCtr = 0;
        int pageCtr = 1;

        Properties properties = new Properties();
        long starttime = System.currentTimeMillis();
        // read csv file line by line
        try {
            // declare readers
            outputStream = new DataOutputStream(new FileOutputStream("heap." + pageSize));
//            String Index 1byte:hash conflict(num) 4bytes:index hash bulk : bulk
            indexStream = new DataOutputStream(new FileOutputStream("heap." + pageSize + ".index"));

            // for each line
            String[] line = reader.readNext();
            int currRec = 0;
            while ((line = reader.readNext()) != null) {
                try {

                    // separate the line
                    String[] oneline = line[0].split(",");
                    if (oneline.length < 19) {
                        continue;
                    }
                    censusYear = oneline[0];
                    blockId = oneline[1];
                    propId = oneline[2];
                    basePropId = oneline[3];
                    name = oneline[4];
                    addressString = oneline[5];
                    clueSmallArea = oneline[6];
                    constructionYear = oneline[7];
                    refurnishYearString = oneline[8];
                    numFloor = oneline[9];
                    prespace = oneline[10];
                    accessType = oneline[11];
                    accessDesp = oneline[12];
                    accRate = oneline[13];
                    bicycle_space = oneline[14];
                    hasShower = oneline[15];
                    xcoordinate = oneline[16];
                    ycoordinate = oneline[17];
                    location = oneline[18] + "," + oneline[19];

                    String hashkey = hashStr(oneline[hashIndex]);
                    if (properties.getProperty(hashkey) == null) {
                        properties.setProperty(hashkey, String.valueOf((pageCtr - 1) * pageSize + currRec * 749));
                    } else {
                        int i = 1;
                        while (properties.getProperty(hashkey + "_" + String.valueOf(i)) != null) {
                            i++;
                        }
                        properties.setProperty(hashkey + "_" + String.valueOf(i), String.valueOf((pageCtr - 1) * pageSize + currRec * 749));
                    }
                    // censusyear

                    byte[] storedCensusYear = Arrays.copyOf(censusYear.getBytes(), censusYearSize);

                    byte[] storedBlockIdByte = Arrays.copyOf(blockId.getBytes(), blockIdSize);

                    byte[] storedpropIdByte = Arrays.copyOf(propId.getBytes(), propIdSize);

                    byte[] storedbasePropIdByte = Arrays.copyOf(basePropId.getBytes(), basePropIdsize);

                    byte[] storednameByte = Arrays.copyOf(name.getBytes(), nameSize);

                    byte[] storedaddressStringByte = Arrays.copyOf(addressString.getBytes(), addressStringSize);

                    byte[] storedclueSmallAreaByte = Arrays.copyOf(clueSmallArea.getBytes(), clueSmallAreaSize);

                    byte[] storedconstructionYearByte = Arrays.copyOf(constructionYear.getBytes(), constructionYearSize);

                    byte[] storedrefurnishYear = Arrays.copyOf(refurnishYearString.getBytes(), refurnishYearStringSize);

                    byte[] storednumFloor = Arrays.copyOf(numFloor.getBytes(), numFloorSize);

                    byte[] storedprespace = Arrays.copyOf(prespace.getBytes(), prespaceSize);

                    byte[] storedaccessType = Arrays.copyOf(accessType.getBytes(), accessTypeSize);

                    byte[] storedaccessDesp = Arrays.copyOf(accessDesp.getBytes(), accessDespSize);

                    byte[] storedaccRate = Arrays.copyOf(accRate.getBytes(), accRateSize);

                    byte[] storedbicycle_space = Arrays.copyOf(bicycle_space.getBytes(), bicycle_spaceSize);
                    byte[] storedhasShower = Arrays.copyOf(hasShower.getBytes(), hasShowerSize);

                    byte[] storedxcoordinate = Arrays.copyOf(xcoordinate.getBytes(), xcoordinateSize);
                    byte[] storedycoordinate = Arrays.copyOf(ycoordinate.getBytes(), ycoordinateSize);

                    byte[] storedlocation = Arrays.copyOf(location.getBytes(), locationSize);

                    outputStream.write(storedCensusYear);
                    outputStream.write(storedBlockIdByte);
                    outputStream.write(storedpropIdByte);

                    outputStream.write(storedbasePropIdByte);
                    outputStream.write(storednameByte);
                    outputStream.write(storedaddressStringByte);
                    outputStream.write(storedclueSmallAreaByte);
                    outputStream.write(storedconstructionYearByte);
                    outputStream.write(storedrefurnishYear);
                    outputStream.write(storednumFloor);
                    outputStream.write(storedprespace);
                    outputStream.write(storedaccessType);
                    outputStream.write(storedaccessDesp);
                    outputStream.write(storedaccRate);
                    outputStream.write(storedbicycle_space);
                    outputStream.write(storedhasShower);
                    outputStream.write(storedxcoordinate);
                    outputStream.write(storedycoordinate);
                    outputStream.write(storedlocation);

                    currRec++;
                    recordCtr++;
                    if (currRec == recordPerPage) {
                        currRec = 0;
                        pageCtr++;
                        for (int i = 0; i < remainderPage; i++) {
                            outputStream.write(0);
                        }
                    }
//                    if (recordCtr > 10000) {
//                        break;
//                    }
                    System.out.println(recordCtr);

                } catch (Exception e) {
                    continue;
                }
            }
            for (int i = 0; i < (recordPerPage - currRec) * recordSize + remainderPage; i++) {
                outputStream.write(0);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            properties.store(indexStream, "none");
        } catch (IOException e) {
            e.printStackTrace();
        }

        long endTime = System.currentTimeMillis();
        long totalTime = endTime - starttime;
        System.out.println("head." + pageSize + " was created in " + totalTime + " ms." + "\nNumber of records: " + recordCtr + "\nNumber of pages: " + pageCtr + "\n");
    }

}
