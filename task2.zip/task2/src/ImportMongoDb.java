import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.BulkWriteOptions;
import com.mongodb.client.model.InsertOneModel;
import com.opencsv.CSVReader;

public class ImportMongoDb {
   public static void insertData(MongoCollection mongo) throws IOException {
      List<InsertOneModel<Document>> documents = new ArrayList<>();
      Document document;
      @SuppressWarnings("deprecation")
      CSVReader reader = new CSVReader(new FileReader("Buildings.csv"), '\t');
      String[] list1 = reader.readNext();
      int loop = 0;
      int bufferSize = 5000;
      while ((list1 = reader.readNext()) != null) {
          String[] list = list1[0].split(",");
         documents.add(new InsertOneModel<>(document = new Document("Census year", list[0]).append("Block ID", list[1])
               .append("Property ID", list[2]).append("Base property ID", list[3]).append("Building name", list[4])
               .append("Street address", list[5]).append("CLUE small area", list[6]).append("Construction year", list[7])
               .append("Refurbished year", list[8]).append("Number of floors", list[9]).append("Predominant space use", list[10])
               .append("Accessibility type", list[11]).append("Accessibility type description", list[12]).append("Accessibility rating", list[13])               
               .append("Bicycle spaces", list[14]).append("Has showers", list[15]).append("x coordinate", list[16])
               .append("y coordinate", list[17]).append("Location", list[18])));
         if (++loop % bufferSize == 0) {
            mongo.bulkWrite(documents, new BulkWriteOptions());
            documents.clear();
         }
         System.out.println(loop);
      }
      mongo.bulkWrite(documents, new BulkWriteOptions());
   }
   

   public static void main(String[] args) throws IOException {
      long start = System.currentTimeMillis();
          MongoClient mongoClient = new MongoClient("10.88.184.78", 27017);
          MongoDatabase DB = mongoClient.getDatabase("MongoDB");
          MongoCollection mongColl = DB.getCollection("Buildings");
         insertData(mongColl);
      long elapsedTime = System.currentTimeMillis() - start;
      float total = elapsedTime / (1000F);
      System.out.println("Finished. time spent: " + total +"seconds");
   }

}
